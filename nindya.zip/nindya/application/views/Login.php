<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page Nindya Test</title>
	<link rel="shortcut icon" href="<?php echo base_url();?>public/img/favicon.png" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/css/login.css">
</head>
 <body class="text-center">
    <form class="sign-form" method="post" id="proses_form" action="<?php echo site_url();?>/login/login_cek">
      
		<h4 class="card-title mt-3 text-center" style="color:#005f3b;">Sign In</h4>
		<p class="text-center" style="color:#005f3b;">Sign in to your account</p>
			<center>
				<input type="text" class="form-control col-md-10" placeholder="Username" id="email" name="username" value="ninjar@test.id" required>
			</center>
			<br/>
			<center>
				<input type="password" class="form-control col-md-10" placeholder="Password" id="pwd" name="password" value="Admin1234" required>
			</center>
			<br/>
			<center><button class="btn btn-md btn-primary col-md-10 btn_login" type="submit" style="background-color:#e2eee8;border:1px solid #005f3b; color:#005f3b; font-weight:bold;">Sign In</button></center>
			<p style="font-size:1px;">&nbsp;</p>
			<span style="color:red;" class="alert_info">&nbsp;</span>
			<p style="font-size:1px;">&nbsp;</p>
			<p><img src="<?php echo base_url(); ?>public/img/logo.png" width="110px"></p>
	
    </form>
  </body>

<script src="<?php echo base_url(); ?>public/js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>public/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>public/js/jquery.form.js"></script>
<script>
$(function() {
	$("#proses_form").ajaxForm({
		beforeSend : function() {
			$(".btn_login").html('Loading');
			$(".alert_info").html('&nbsp;');
		},
		success : function() {
			$(".btn_login").html('Sign In');
		},
		complete : function(xhr) {
			var obj = jQuery.parseJSON(xhr.responseText);
			if(obj.status == "error") {
				$(".alert_info").html(obj.msg);
			}else {
				window.location = "<?php echo site_url();?>/Home";
			}
		}
	});
	
});
</script>