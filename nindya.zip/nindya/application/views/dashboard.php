<div class="col-lg-6">
	<div class="card">
		<div class="card-header">
			<div>
				<table width="100%">
					<tr>
						<td><h6 class="mg-b-5">Penjualan (Wilayah)</h6></td>
						<td align="right"><span class="filter_view"><span class="btn btn-dark btn-sm btn_filter">Filter Date</span></span></td>
					</tr>
				</table>
				
			</div>
		</div>
		<div class="card-body">
			<table width="100%" style="">
				<thead style="background-color:#e2eee8;text-align:center; color:#005f3b;">
					<tr>
						<th>No</th>
						<th>Tanggal</th>
						<th>Wilayah</th>
						<th>Produksi</th>
					</tr>
				</thead>
				<tbody class="tabel_penjualan" style="text-align:center;">
				</tbody>
			</table>
		</div>
	</div>
</div>
<div class="col-lg-6">
	<div class="card">
		<div class="card-header">
			<div>
				<h6 class="mg-b-5">Graph Penjualan (Wilayah)</h6>
				
			</div>
		</div>
		<div class="card-body">
			<canvas id="canvas"></canvas>
		</div>
	</div>
</div>

<div class="col-lg-6">
	<div class="card">
		<div class="card-header">
			<div>
				<table width="100%">
					<tr>
						<td><h6 class="mg-b-5">Penjualan Summary</h6></td>
						<td align="right"><span class="filter_view_summary"><span class="btn btn-dark btn-sm btn_filter_summary">Filter Month</span></span></td>
					</tr>
				</table>
				
			</div>
		</div>
		<div class="card-body">
			<table width="100%" style="">
				<thead style="background-color:#e2eee8;text-align:center; color:#005f3b;">
					<tr>
						<th>No</th>
						<th>Tanggal</th>
						<th>Produksi</th>
					</tr>
				</thead>
				<tbody class="tabel_penjualan_summary" style="text-align:center;">
				</tbody>
			</table>
		</div>
	</div>
</div>






<script>
	$(function() {
		get_data();
		get_data_summary();

		$(".btn_filter").click(function() {
			$(".filter_view").html('');
			$(".filter_view").html('<input type="text" class="btn btn-sm col-sm-5 date_pick">&nbsp;<span class="btn btn-sm btn-dark btn_post">Post</span>');
			
			$(".btn_post").click(function() {
				get_data($(".date_pick").val());
			});
			
			$(".date_pick").datepicker({
				format: "yyyy-mm-dd",
				//viewMode: "months", 
				//minViewMode: "months",
				autoclose: true	
			});
		});
	});
	
	$(".btn_filter_summary").click(function() {
		$(".filter_view_summary").html('');
		$(".filter_view_summary").html('<input type="text" class="btn btn-sm col-sm-5 date_pick_sum">&nbsp;<span class="btn btn-sm btn-dark btn_post_sum">Post</span>');
		
		$(".btn_post_sum").click(function() {
			get_data_summary($(".date_pick_sum").val());
		});
		
		$(".date_pick_sum").datepicker({
				format: "yyyy-mm",
				viewMode: "months", 
				minViewMode: "months",
				autoclose: true	
		});
			
	});
	
	function get_data_summary(param) {
		$.ajax({
			url : "<?php echo site_url();?>/home/list_summary",
			type : "POST",
			data : {'get_month':param},
			beforeSend : function() {
				$(".tabel_penjualan_summary").html('<tr><td colspan="3">Loading...</td></tr>');
			},
			success : function(data) {
				$(".tabel_penjualan_summary").html('');
				var obj = jQuery.parseJSON(data);
				var no_data = "";
				var m=0;
				if(obj.length > 0 ) {
					for ( var i = 0; i < obj.length; i++) {
						m++;
						var bg = (m%2 == 0 ) ? "#f2f3f5" :"";
						no_data += "<tr bgcolor='"+bg+"'>"+
										"<td>"+m+"</td>"+
										"<td>"+obj[i].tanggal+"</td>"+
										"<td>"+obj[i].total_produksi+"</td>"+
									"</tr>";
				

					}
				}else {
					no_data += '<tr><td colspan="3">Data tidak ditemukan</td></tr>';
				}
				
				$(".tabel_penjualan_summary").html(no_data);
			}
		});
	}
	function get_data(param) {
		$.ajax({
			url : "<?php echo site_url();?>/home/list_data",
			type : "POST",
			data : {'get_date':param},
			beforeSend : function() {
				$(".tabel_penjualan").html('<tr><td colspan="4">Loading...</td></tr>');
			},
			success : function(data) {
				$(".tabel_penjualan").html('');
				var obj = jQuery.parseJSON(data);
				var no_data = "";
				var m=0;
				if(obj.length > 0 ) {
					for ( var i = 0; i < obj.length; i++) {
						m++;
						var bg = (m%2 == 0 ) ? "#f2f3f5" :"";
						no_data += "<tr bgcolor='"+bg+"'>"+
									"<td>"+m+"</td>"+
									"<td>"+obj[i].tanggal+"</td>"+
									"<td>"+obj[i].wilayah+"</td>"+
									"<td>"+obj[i].produksi+"</td>"+
									"</tr>";
				

					}
				}else {
					no_data += '<tr><td colspan="4">Data tidak ditemukan</td></tr>';
				}

				$(".tabel_penjualan").html(no_data);

				var jsonfile ={"jsonarray": obj};
				var labels = jsonfile.jsonarray.map(function(e) {
					return e.wilayah;
				});
				var data = jsonfile.jsonarray.map(function(e) {
					return e.produksi;
				});
	
				var ctx = canvas.getContext('2d');
				var config = {
				type: 'line',
				data: {
					labels: labels,
					datasets: [{
					label: 'Wilayah',
					data: data,
					backgroundColor: 'rgba(0, 119, 204, 0.3)'
				}]
				}
				};
	
				var chart = new Chart(ctx, config);				
			
			}
		});
	}
	
	function dalam_bulan() {
		$.ajax({
			url : "<?php echo site_url();?>/Home/dalam_bulan",
			type : "POST",
			beforeSend :function() {
				$(".dalam_bulan").html("Loading....");
			},
			success : function(xhr) {
				$(".dalam_bulan").html(xhr);
				return false;
			}
		});
	}
</script>