<?php 
$post = $this->input->post('get_month');
$list=array();
if(empty($post)) {
	$month = date('m');
	$year = date('Y');
}else {
	$month = date('m',strtotime($this->input->post('get_month')));
	$year = date('Y',strtotime($this->input->post('get_month')));
}

for($i=1; $i<=31; $i++) {
	$bulan =  date('m', mktime(0, 0, 0, $i, 1));
	
	//$arr_month[] = date('F', mktime(0, 0, 0, $i, 1));
	
	$time=mktime(12, 0, 0, $month, $i, $year);          
    if (date('m', $time)==$month)       
        $list[]=date('d', $time);
	$tgl = date('d', $time);
	
	$sql = "select sum(produksi) total_produksi from tb_data where date_format(tanggal,'%Y-%m-%d') = '$year-$month-$tgl' group by tanggal";
	$query = $this->db->query($sql);
	if($query->num_rows() == '' ) {
		$data = "0";
	}else {
		$m = $query->first_row();
		$data = $m->total_produksi;
	}
	
	$aData[] = $data;
	
	
}

$result_x = "'" . implode ( "', '", $list ) . "'";
$value_y = implode(",",$aData);
?>
<canvas id="chartArea1" width="728" height="300" class="chartjs-render-monitor" style="display: block; width: 728px; height: 300px;"></canvas>
<script>
$(function() {
	var ctxLabel = [<?php echo $result_x;?>];
	var ctxData1 = [<?php echo $value_y;?>];
  
  var ctxColor1 = '#001737';
  
	  // Area chart
  var ctx5 = document.getElementById('chartArea1');
  new Chart(ctx5, {
    type: 'line',
    data: {
      labels: ctxLabel,
      datasets: [{
        data: ctxData1,
        borderColor: ctxColor1,
        borderWidth: 1,
        backgroundColor: '#88C4FF'
      }]
    },
    options: {
      maintainAspectRatio: false,
      legend: {
        display: false,
          labels: {
            display: false
          }
      },
      scales: {
        yAxes: [{
          stacked: true,
          gridLines: {
            color: '#e5e9f2'
          },
          ticks: {
            beginAtZero:true,
            fontSize: 10
          }
        }],
        xAxes: [{
          stacked: true,
          gridLines: {
            display: false
          },
          ticks: {
            beginAtZero:true,
            fontSize: 11
          }
        }]
      }
    }
  });
});
</script>