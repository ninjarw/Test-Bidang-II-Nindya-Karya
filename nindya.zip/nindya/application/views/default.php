<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT Nindya Karya (Persero)</title>
	<link rel="shortcut icon" href="<?php echo base_url(); ?>public/img/favicon.png" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>public/css/bootstrap-datepicker.css">
	
	<script src="<?php echo base_url(); ?>public/js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>public/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>public/js/jquery.form.js"></script>
	<script src="<?php echo base_url(); ?>public/js/Chart.min.js"></script>
	<script src="<?php echo base_url(); ?>public/js/bootstrap-datepicker.js"></script>
	
</head>
<body>
	<?php echo $navigationContent;?>
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div>
					<h4 class="mg-b-0 tx-spacing--1"><?php echo $title;?></h4>
				</div>
			</div>
		
			<?php echo $mainContent;?>
		</div>
	</div>
</body>
</html>