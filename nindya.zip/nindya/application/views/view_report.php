<script src="<?php echo base_url();?>public/js/Chart.bundle.min.js"></script>
<div class="col-lg-3">
	<div class="card">
		<div class="card-header"><h6>Filter</h6></div>
		<div class="card-body">
			<table width="100%">
				<tr>
					<td><input type="text" class="form-control datepick"></td>
				</tr>
				<tr><td>&nbsp;</td></tr>
				<tr>
					<td><button class="btn btn-dark btn-block btn_submit">Submit</button></td>
				</tr>
				
			</table>
		</div>
	</div>
</div>
<div class="col-lg-9">
	<div class="card">
		<div class="card-header"><h6>Produksi</h6></div>
		<div class="card-body">
			<div class="hasil_produksi"></div>
		</div>
	</div>
	
</div>

<script>
$(function() {
	hasil_produksi();
			$(".datepick").datepicker({
				format: "yyyy-mm",
				viewMode: "months", 
				minViewMode: "months",
				autoclose: true	
			});
	$(".btn_submit").click(function() {
		hasil_produksi($(".datepick").val());
	});		
	
});

function hasil_produksi(param) {
	$.ajax({
		url : "<?php echo site_url();?>/report/hasil_produksi",
		type : "POST",
		data : {'get_month':param},
		beforeSend:function() {
			$(".hasil_produksi").html('Loading...');
		},
		success : function(xhr) {
			$(".hasil_produksi").html(xhr);
			return false;
		}
	});
}
</script>