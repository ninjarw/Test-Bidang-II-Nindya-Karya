<?php 
class Login_act extends CI_Model	{
	function login_cek($post) {
		$username = $post['username'];
		$password = $post['password'];
		
		$sql = "* from tb_user  where username='".$username."' and password='".$password."' ";
		$this->db->select($sql,false);
		$query = $this->db->get();
		if($query->num_rows() > 0 ) {
			$result = $query->first_row();
		}else {
			$result = false;
		}
		
		return $result;
	}
}
?>