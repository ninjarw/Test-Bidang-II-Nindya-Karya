<?php 
Class Report_act extends CI_Model	{

}
?>