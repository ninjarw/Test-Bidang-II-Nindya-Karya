<?php 
Class Home_act extends CI_Model	{
	function list_data($post) {
		if(!empty($post['get_date'])) {
			$where = "where tanggal='".date('Y-m-d',strtotime($post['get_date']))."' ";
		}else {
			$where = "";
		}
		
		$sql = "select * from tb_data $where";
		$query = $this->db->query($sql);
		if($query->num_rows > 0 ) {
			$res = $query->result();
		}else {
			$res = "";
		}
		
		return $res;
	}
	
	function list_summary($post) {
		if(!empty($post['get_month'])) {
			$where = "where date_format(tanggal,'%Y-%m')='".date('Y-m',strtotime($post['get_month']))."' ";
		}else {
			$where = "";
		}
		
		$sql = "select tanggal, sum(produksi) total_produksi
				from tb_data
				$where
				group by tanggal ";
		$query = $this->db->query($sql);
		if($query->num_rows > 0 ) {
			$res = $query->result();
		}else {
			$res = "";
		}
		
		return $res;
	}
}
?>