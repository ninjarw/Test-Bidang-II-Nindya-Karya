<?php 
Class Home extends CI_Controller	{
	function __construct() {
		parent:: __construct();

		
		
		$this->load->library('encrypt');
		$this->newsession = ($this->session->userdata('logged_in')) ? $this->session->userdata('logged_in') : '';
		$this->load->model('home_act');
	}
	function template($content,$main) {
		$logged_in = $this->session->userdata('logged_in');
		if($logged_in != TRUE || empty($logged_in))	{
			#user not logged in
			$this->session->set_flashdata('error', 'Session has Expired');
			redirect('login'); # Login view
		}else{
			$arr = array('');
			$data = array(
				'navigationContent'=>$this->load->view('headerContent',$arr,true),
				'mainContent'=>$this->load->view($content,$main,true),
			);
			
			return $data;
			
		}

	}
	
	function index() {
		$count = array('session'=>$this->newsession,'title'=>'Dashboard');
		$data = $this->template('dashboard', $count);
		$this->load->view('default', $data);
	}
	
	function list_data() {
		$post = $this->input->post();
		$data = $this->home_act->list_data($post);
		
		echo json_encode($data);
	}
	
	function list_summary() {
		$post = $this->input->post();
		$data = $this->home_act->list_summary($post);
		
		echo json_encode($data);
	}
	
	function dalam_bulan() {
		$this->load->view('dalam_bulan');
	}
}
?>