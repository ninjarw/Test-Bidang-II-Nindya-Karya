<?php 
include_once (dirname(__FILE__) . "/Home.php");	

Class Report extends Home	{
	function __construct() {
		parent::__construct();
		$this->load->model('report_act');
		
	}
	
	function index() {
		$data = array (
					'title'=>'Report') ;
		
	
		
		$main = $this->template('view_report',$data);
		$this->load->view('default',$main);
	}
	
	function hasil_produksi() {
		$this->load->view('hasil_produksi');
	}
}
?>