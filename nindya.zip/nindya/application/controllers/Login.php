<?php 
Class Login extends CI_Controller	{
	function __construct() {
		parent:: __construct();
		$this->load->model('login_act');
	}
	
	function index() {
		if($this->session->userdata('logged_in')){
			redirect('home','refresh');
			
		}else {
			$msg = '';
			
			if($this->session->flashdata('information')){
				$msg = $this->session->flashdata('information');
			}
			
			$this->load->view('Login');
		}
	}
	
	function login_cek() {
		$res = $this->login_act->login_cek($this->input->post());
		if($res) {
			setcookie("logged_in", 'true', time()+3600, '/');
			$this->session->set_userdata('logged_in', $res);
			$msg = "";
			$status = "success";
		}else {
			$msg = "Invalid Username & Password";
			$status = "error";
		}
		
		echo json_encode(array('status'=>$status, 'msg'=>$msg));
	}
	
	function logout() {
		setcookie("logged_in", 'false', time()-42000, '/');
		$this->load->driver('cache');
		$this->session->unset_userdata('logged_in');
		
		$this->session->sess_destroy();
		$this->cache->clean();
		


		redirect('login');
	}
}
?>